USE projeto02;

INSERT INTO usuario (nome_usuario, email_usuario, telefone)
VALUES ('Ellen', "ellen12@gmail.com", "11981291289");

SELECT * FROM usuario;