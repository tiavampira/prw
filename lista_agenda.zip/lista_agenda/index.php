<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu principal - IFSP</title>
    <link rel="stylesheet" href="estilo.css">
</head>
<body>
    <h1><font color="#FF0000">Menu principal</font></h1>
    <h1><font color="#32CD32">Agenda</font></h1>
    <div id="menu">
        
            <h3>
            <li><a href="cadastro_agenda.html"> Cadastrar Contato</a></li>
            <li><a href="listar_agenda.php"> Listar Agenda</a></li>
            </h3>
        
    </div>
</body>
</html>